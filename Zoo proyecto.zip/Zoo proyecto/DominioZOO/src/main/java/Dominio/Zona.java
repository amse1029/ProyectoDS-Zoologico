package Dominio;

/**
 * 
 */
public class Zona {

    /**
     * Default constructor
     */
    public Zona() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private float extension;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getExtension() {
        return extension;
    }

    public void setExtension(float extension) {
        this.extension = extension;
    }

    
    
}