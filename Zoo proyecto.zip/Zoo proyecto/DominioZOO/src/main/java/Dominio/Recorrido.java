package Dominio;

/**
 * 
 */
public class Recorrido {

    /**
     * Default constructor
     */
    public Recorrido() {
    }

    /**
     * 
     */
    private float duracion;

    /**
     * 
     */
    private float longitud;

    public float getDuracion() {
        return duracion;
    }

    public void setDuracion(float duracion) {
        this.duracion = duracion;
    }

    public float getLongitud() {
        return longitud;
    }

    public void setLongitud(float longitud) {
        this.longitud = longitud;
    }

    
    
}