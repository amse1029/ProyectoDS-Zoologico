package Dominio;

/**
 * 
 */
public class Guia extends Empleado {

    /**
     * Default constructor
     */
    public Guia() {
    }

}