/**
* FabricaDatos.java
* May 8, 2023 11:06:01 PM
*/ 

package itson.DAOs;

/**
 *
 * 
 * @author Joel Antonio Lopez Cota ID:228926 
 */
public class FabricaDatos {

    
    public static IDatos crearInstancia(){
        return new FachadaDatos();
    }
}
