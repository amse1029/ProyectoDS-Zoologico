package Dominio;

/**
 * Enumerador con los días de la semana.
 */
public enum Dias {
    Lunes,
    Martes,
    Miercoles,
    Jueves,
    Viernes,
    Sabado,
    Domingo
}